import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <main className="min-h-screen flex">
      {/* Left side - Brand section */}
      <div className="hidden lg:flex lg:w-1/2 bg-[#0d4a8c] flex-col justify-between p-12">
        <div>
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-NTLbKlPB2ObVfjpyDhzXCdi2NAFtuv.png"
            alt="KOSMOS Logo"
            className="h-12 w-auto"
          />
        </div>
        
        <div className="space-y-6">
          <h1 className="text-4xl font-bold text-white leading-tight text-balance">
            Entdecken Sie die Welt von KOSMOS
          </h1>
          <p className="text-white/80 text-lg leading-relaxed max-w-md">
            Bücher, Spiele und Experimentierkästen, die inspirieren und begeistern. Melden Sie sich an, um Zugang zu Ihrem Konto zu erhalten.
          </p>
        </div>
        
        <div className="flex items-center gap-8 text-white/60 text-sm">
          <span>Spiele</span>
          <span className="w-1 h-1 rounded-full bg-white/40" />
          <span>Bücher</span>
          <span className="w-1 h-1 rounded-full bg-white/40" />
          <span>Experimentierkästen</span>
        </div>
      </div>
      
      {/* Right side - Login form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-muted/50">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <div className="bg-[#0d4a8c] p-4 rounded-xl">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-NTLbKlPB2ObVfjpyDhzXCdi2NAFtuv.png"
                alt="KOSMOS Logo"
                className="h-8 w-auto"
              />
            </div>
          </div>
          
          {/* White card wrapper */}
          <div className="bg-card rounded-2xl shadow-lg border border-border p-8 space-y-8">
            <div className="space-y-2 text-center lg:text-left">
              <h2 className="text-2xl font-bold text-foreground">
                Willkommen zurück
              </h2>
              <p className="text-muted-foreground">
                Melden Sie sich mit Ihren Zugangsdaten an
              </p>
            </div>
            
            <LoginForm />
            
            <p className="text-center text-sm text-muted-foreground">
              Noch kein Konto?{" "}
              <a href="#" className="font-medium text-primary hover:underline">
                Jetzt registrieren
              </a>
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
